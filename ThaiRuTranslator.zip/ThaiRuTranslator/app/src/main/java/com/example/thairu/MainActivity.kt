package com.example.thairu

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.nl.translate.*
import com.google.mlkit.common.model.DownloadConditions
import cz.adaptech.tesseract4android.TessBaseAPI
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private var thToRu = true
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var dirBtn: Button
    private var translator: Translator? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null

    private val srcLoc get() = if (thToRu) Locale("th", "TH") else Locale("ru", "RU")
    private val dstLoc get() = if (thToRu) Locale("ru", "RU") else Locale("th", "TH")

    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@registerForActivityResult
        output.text = "Распознаю текст…"
        thread {
            try {
                val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
                val api = TessBaseAPI()
                api.init(filesDir.absolutePath, if (thToRu) "tha" else "rus")
                api.setImage(bmp)
                var text = api.utf8Text.orEmpty()
                api.recycle()
                // Tesseract вставляет пробелы между тайскими буквами — убираем
                text = text.replace(Regex("(?<=[\\u0E00-\\u0E7F])[ \\t]+(?=[\\u0E00-\\u0E7F])"), "").trim()
                runOnUiThread { input.setText(text); translate() }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Ошибка OCR: ${e.message}" }
            }
        }
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listen() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        copyTessData()
        tts = TextToSpeech(this) { }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        dirBtn = Button(this).apply { setOnClickListener { thToRu = !thToRu; setupTranslator() } }
        input = EditText(this).apply { hint = "Текст…"; minLines = 3; gravity = android.view.Gravity.TOP }
        output = TextView(this).apply { textSize = 20f; setTextIsSelectable(true); setPadding(0, 24, 0, 24) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            btn("Перевести") { translate() },
            btn("🎤") { micClick() },
            btn("📷") { pickImage.launch("image/*") },
            btn("🔊") { speak() }
        ).forEach { row.addView(it, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)) }
        root.addView(dirBtn); root.addView(input); root.addView(row)
        root.addView(ScrollView(this).apply { addView(output) })
        setContentView(root)
        setupTranslator()
    }

    private fun copyTessData() {
        val dir = File(filesDir, "tessdata").apply { mkdirs() }
        assets.list("tessdata")?.filter { it.endsWith(".traineddata") }?.forEach { n ->
            val f = File(dir, n)
            if (!f.exists()) assets.open("tessdata/$n").use { i -> f.outputStream().use { i.copyTo(it) } }
        }
    }

    private fun setupTranslator() {
        dirBtn.text = if (thToRu) "Тайский → Русский (нажми, чтобы сменить)" else "Русский → Тайский (нажми, чтобы сменить)"
        translator?.close()
        val (s, t) = if (thToRu) TranslateLanguage.THAI to TranslateLanguage.RUSSIAN
                     else TranslateLanguage.RUSSIAN to TranslateLanguage.THAI
        translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build()
        )
        output.text = "Загружаю языковые модели (нужен интернет только один раз)…"
        val tr = translator!!
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { output.text = "Готово, работает оффлайн." }
            .addOnFailureListener { output.text = "Не удалось скачать модель: ${it.message}" }
    }

    private fun translate() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        translator?.translate(text)
            ?.addOnSuccessListener { output.text = it }
            ?.addOnFailureListener { output.text = "Ошибка перевода: ${it.message}" }
    }

    private fun speak() {
        val text = output.text.toString()
        tts?.language = dstLoc
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun micClick() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
        else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun listen() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let {
                        input.setText(it); translate()
                    }
                }
                override fun onError(e: Int) { output.text = "Ошибка распознавания ($e). Скачай оффлайн-пакет языка в настройках Google." }
                override fun onReadyForSpeech(p: Bundle?) { output.text = "Говори…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, srcLoc.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            })
        }
    }

    override fun onDestroy() { translator?.close(); tts?.shutdown(); recognizer?.destroy(); super.onDestroy() }
}
