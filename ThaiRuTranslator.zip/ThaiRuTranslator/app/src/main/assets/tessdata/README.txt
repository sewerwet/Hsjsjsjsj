Положи сюда tha.traineddata и rus.traineddata (из github.com/tesseract-ocr/tessdata_fast).
