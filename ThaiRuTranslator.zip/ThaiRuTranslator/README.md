# Тай⇄Рус оффлайн переводчик (Android)

1. Скачай tha.traineddata и rus.traineddata (tessdata_fast) -> app/src/main/assets/tessdata/
2. Открой папку в Android Studio, дождись Gradle sync, запусти на телефоне.
3. Первый запуск: с интернетом, чтобы скачались модели перевода (th, ru). Дальше без сети.
4. Оффлайн голос: Настройки -> Google -> Голосовой ввод -> Оффлайн-распознавание: скачать Thai и Russian.
   Озвучка: Настройки -> Язык -> Синтез речи -> Google TTS -> установить голоса Thai и Russian.
